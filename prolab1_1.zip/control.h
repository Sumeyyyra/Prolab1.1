#ifndef CONTROL_H
#define CONTROL_H

// Eğer koordinatları nasılayırdığını merak ediyorsanız bu fonksiyonun olduğu yorum satırını kaldırın.
void coordinate_control();

#endif